package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout

class MainActivity : AppCompatActivity() {

    private lateinit var upsLogo: ImageView
    private lateinit var welcomeText: TextView
    private lateinit var usernameInputLayout: TextInputLayout
    private lateinit var passwordInputLayout: TextInputLayout
    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginBtn: Button
    private lateinit var forgotPasswordText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var helpText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupInputValidation()
        setupClickListeners()
    }

    private fun initializeViews() {
        upsLogo = findViewById(R.id.ups_logo)
        welcomeText = findViewById(R.id.welcome_text)
        usernameInputLayout = findViewById(R.id.username_input_layout)
        passwordInputLayout = findViewById(R.id.password_input_layout)
        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        loginBtn = findViewById(R.id.login_btn)
        forgotPasswordText = findViewById(R.id.forgot_password_text)
        progressBar = findViewById(R.id.progress_bar)
        helpText = findViewById(R.id.help_text)
    }

    private fun setupInputValidation() {
        usernameInput.addTextChangedListener(createTextWatcher { text ->
            validateUsername(text)
        })

        passwordInput.addTextChangedListener(createTextWatcher { text ->
            validatePassword(text)
        })
    }

    private fun setupClickListeners() {
        loginBtn.setOnClickListener {
            if (validateInputs()) {
                attemptLogin()
            }
        }

        forgotPasswordText.setOnClickListener {
            // Handle forgot password
            // Add UPS password recovery logic here
        }

        helpText.setOnClickListener {
            // Handle help button click
            // Add UPS help center logic here
        }
    }

    private fun validateInputs(): Boolean {
        val isUsernameValid = validateUsername(usernameInput.text.toString())
        val isPasswordValid = validatePassword(passwordInput.text.toString())
        return isUsernameValid && isPasswordValid
    }

    private fun validateUsername(username: String): Boolean {
        return when {
            username.isEmpty() -> {
                usernameInputLayout.error = "Employee ID required"
                false
            }
            username.length < 4 -> {
                usernameInputLayout.error = "Invalid Employee ID"
                false
            }
            else -> {
                usernameInputLayout.error = null
                true
            }
        }
    }

    private fun validatePassword(password: String): Boolean {
        return when {
            password.isEmpty() -> {
                passwordInputLayout.error = "Password required"
                false
            }
            password.length < 8 -> {
                passwordInputLayout.error = "Password must be at least 8 characters"
                false
            }
            else -> {
                passwordInputLayout.error = null
                true
            }
        }
    }

    private fun attemptLogin() {
        showLoading(true)

        val username = usernameInput.text.toString()
        val password = passwordInput.text.toString()

        Log.i("UPS_Login", "Attempting login for employee: $username")

        // Simulate network delay (replace with actual login logic)
        loginBtn.postDelayed({
            showLoading(false)
            navigateToHomepage()
        }, 1000)
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        loginBtn.isEnabled = !show
        usernameInput.isEnabled = !show
        passwordInput.isEnabled = !show
    }

    private fun navigateToHomepage() {
        val intent = Intent(this, Homepage::class.java)
        startActivity(intent)
        finish()
    }

    private fun createTextWatcher(validateFunction: (String) -> Unit): TextWatcher {
        return object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                s?.toString()?.let { validateFunction(it) }
            }
        }
    }
}